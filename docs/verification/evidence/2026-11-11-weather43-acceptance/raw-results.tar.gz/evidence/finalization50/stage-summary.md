# Weather43 local experiment stage

Finished: 2026-11-10T21:59:12.624790+00:00

Concurrency: 50 environment requests. Historical 350/1000 results remain separate.

Real source update observation completed: True

Audit command outcomes:

- voice-recount: exit 0
- exact-fixture-cleanup: exit 0
- source-update-audit: exit 0
- full-raw-recount: exit 0

A completed experiment or successful command does not imply a deployment recommendation. Review raw failures, voice ratios, cold overlap, source availability and sampled resources.
