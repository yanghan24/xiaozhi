"""Allowlisted, non-secret final weather43 evidence export; no private config/DB."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import shutil
import subprocess
import sys
import tarfile
import yaml

p=argparse.ArgumentParser()
p.add_argument('--root',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--source-commit',required=True)
p.add_argument('--voice-outcome',choices=['completed','failed','blocked'],default='completed')
p.add_argument('--research-outcome',choices=['continue','stop'],required=True)
a=p.parse_args();r=a.root.resolve();out=a.output.resolve()
sys.path.insert(0,str(r/'scripts/weather43'))
from metrics_report import docker_memory
assert out.is_relative_to(r) if hasattr(out,'is_relative_to') else str(out).startswith(str(r)+'/')
assert not out.exists();out.mkdir()
for marker in ['long-load-suite-complete','recovery-complete','network-restart-complete','network-soak/summary.json','voice/fixture-cleanup.json','update-observation/final-audit.json','finalization50/finished.json','metrics-final-observation.json']:
 assert (r/'evidence'/marker).exists(),marker
if a.voice_outcome=='completed':
 comparison=json.loads((r/'evidence/voice/account2/comparison.json').read_text())
 assert comparison['raw_integrity_passed'] and comparison['all_real_questions_succeeded'] and comparison['same_account_generation_and_product_source']
 assert (r/'evidence/coexistence-finished').exists()
elif a.voice_outcome=='blocked':
 blocked=json.loads((r/'evidence/voice/acceptance-blocked.json').read_text())
 assert blocked['status']=='blocked' and blocked['full_voice_acceptance_passed'] is False
 diagnostic=json.loads((r/'evidence/voice/asr-upstream-diagnostic-message.json').read_text())
 assert any(x.get('http')==400 and '\u79ef\u5206\u4e0d\u8db3' in x.get('sanitized_message','') for x in diagnostic['stages'])
else:
 comparison_path=r/'evidence/voice/account2/comparison.json'
 if comparison_path.exists():
  comparison=json.loads(comparison_path.read_text())
  assert not (comparison['all_real_questions_succeeded'] and comparison['same_account_generation_and_product_source'])
 else:assert (r/'evidence/acceptance50-r1/failed.json').exists()
if a.research_outcome=='continue':
 assert json.loads((r/'evidence/update-observation/final-audit.json').read_text())['passed']
 assert (r/'evidence/final-capacity-complete').exists()
 assert a.voice_outcome=='completed' and comparison['primary_warm_comparison_passed']
assert json.loads((r/'private/fault.json').read_text())=={}
def run(args):return subprocess.run(args,capture_output=True,text=True,check=True).stdout
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()
checkpoint_path=r/'evidence/update-observation/completed.json'
if not checkpoint_path.exists():checkpoint_path=r/'evidence/update-observation/checkpoint.json'
checkpoint=json.loads(checkpoint_path.read_text())
latest_source={}
for line in (r/'evidence/update-observation/source-publications.jsonl').read_text().splitlines():
 for model,value in json.loads(line).get('models',{}).items():
  if value.get('metadata'):latest_source[model]=value
recovery=json.loads((r/'evidence/latest-recovery.json').read_text())
cold_directory=(r/recovery['cold_result_directory']).resolve()
assert str(cold_directory).startswith(str(r/'private')+'/')
coverage={}
coverage_rows=[]
databases=[('primary350',r/'private/result-data/results.sqlite3'),('cold1000',cold_directory/'results.sqlite3')]
cold50_paths=r/'evidence/acceptance50-r1/cold-data-paths.json'
cold50_directory=None
if cold50_paths.exists():
 cold50_directory=(r/json.loads(cold50_paths.read_text())['result_directory']).resolve()
 assert str(cold50_directory).startswith(str(r/'private')+'/')
 databases.append(('cold50',cold50_directory/'results.sqlite3'))
for label,database in databases:
 with sqlite3.connect('file:'+str(database)+'?mode=ro',uri=True) as db:rows=list(db.execute('SELECT city,kind,payload FROM results'))
 for city,kind,payload in rows:
  entry=json.loads(payload)
  coverage_rows.append({'fixture':label,'city_id':city,'kind':kind,'model_grid':entry.get('model_grid'),
                        'model_run_at':entry['metadata']['run_at'],'source_metadata_sha256':entry['metadata']['sha256'],
                        'source_published_at':entry['metadata']['published_at'],'fetched_at':entry['fetched_at'],
                        'payload_sha256':entry['payload_sha256']})
 coverage[label]={}
 for kind,model in [('weather','ncep_gfs013'),('air_quality','cams_global')]:
  entries=[json.loads(payload) for _,k,payload in rows if k==kind]
  grids={(x.get('model_grid',{}).get('latitude'),x.get('model_grid',{}).get('longitude')) for x in entries}
  grids.discard((None,None))
  runs=sorted(set(x['metadata']['run_at'] for x in entries))
  metadata_hashes=sorted(set(x['metadata']['sha256'] for x in entries))
  coverage[label][kind]={'entries':len(entries),'unique_returned_model_grids':len(grids),'model_runs':runs,
                         'source_metadata_sha256':metadata_hashes}
  if label=='primary350':
   current=(len(entries)==350 and runs==[max(checkpoint['seen_runs'][model])] and metadata_hashes==[latest_source[model]['sha256']] and
    all(x.get('model_grid',{}).get('latitude') is not None and x.get('model_grid',{}).get('longitude') is not None for x in entries))
   coverage[label][kind]['all_entries_match_latest_observed_run_sha_and_have_grid']=current
   if a.research_outcome=='continue':assert current
(r/'evidence/model-grid-coverage.json').write_text(json.dumps(coverage,indent=2))
with (r/'evidence/model-grid-rows.jsonl').open('w') as grid_log:
 for row in coverage_rows:grid_log.write(json.dumps(row)+'\n')
containers={}
for name in ['xiaozhi-pr26-api','xiaozhi-pr26-voice','xiaozhi-weather43-acceptance-openmeteo-1','xiaozhi-weather43-acceptance-result-cache-1','xiaozhi-weather43-acceptance-data-relay-1']:
 x=json.loads(run(['docker','inspect',name]))[0]
 containers[name]={'image_id':x['Image'],'running':x['State']['Running'],'started_at':x['State']['StartedAt'],'restart_count':x['RestartCount'],'oom_killed':x['State']['OOMKilled']}
env=dict(line.split('=',1) for line in (r/'private/acceptance.env').read_text().splitlines() if '=' in line and not line.startswith('#'))
code="import urllib.request;c=urllib.request.build_opener(urllib.request.ProxyHandler({}));print(c.open('http://"+env['WEATHER43_GATEWAY']+":18085/relay-health').read().decode())"
relay=json.loads(run(['docker','exec','xiaozhi-weather43-acceptance-result-cache-1','python','-c',code]))
final={'at':datetime.now(timezone.utc).isoformat(),'source_commit':a.source_commit,'containers':containers,'source_relay_counters':relay,
       'voice_verification_outcome':a.voice_outcome,
       'research_outcome':a.research_outcome,
       'unadjusted_cgroup_memory':docker_memory(list(containers)),
       'source_file_sha256':{str(path.relative_to(r)):digest(path) for path in (r/'scripts/weather43').glob('*') if path.is_file()},
       'scope':'isolated HTTP/cache feasibility; real server voice protocol; no physical speaker or firmware claim'}
(r/'evidence/runtime-inventory-final.json').write_text(json.dumps(final,indent=2))
files={};excluded=[]
for path in sorted((r/'evidence').rglob('*')):
 if not path.is_file() or path.is_symlink():continue
 name=str(path.relative_to(r))
 if path.name=='china-city-catalog.json':
  excluded.append({'path':name,'sha256':digest(path),'reason':'Large reconstructable public catalogue; raw input receipts and compiler included'})
 else:files[name]=path
for path in (r/'private/result-data').glob('events.jsonl*'):
 files['weather-cache/'+path.name]=path
for path in (r/'private/result-data/publication-snapshots').glob('*.json'):
 files['weather-cache/publication-snapshots/'+path.name]=path
for path in cold_directory.glob('events.jsonl*'):
 files['cold-cache/'+path.name]=path
for path in (cold_directory/'publication-snapshots').glob('*.json'):
 files['cold-cache/publication-snapshots/'+path.name]=path
if cold50_directory:
 for path in cold50_directory.glob('events.jsonl*'):files['cold50-cache/'+path.name]=path
 for path in (cold50_directory/'publication-snapshots').glob('*.json'):
  files['cold50-cache/publication-snapshots/'+path.name]=path
for name in ['cities.json','cities-1000.json','acceptance50-r1-cities50.json']:
 files['fixtures/'+name]=r/'private'/name
for path in (r/'scripts/weather43').glob('*'):
 if path.is_file():files['tools/'+path.name]=path
staging=out/'snapshot';staging.mkdir(mode=0o700)
for name,path in list(files.items()):
 target=staging/name;target.parent.mkdir(parents=True,exist_ok=True)
 shutil.copyfile(path,target)
 if '.jsonl' in path.name:
  for line in target.read_text().splitlines():json.loads(line)
 files[name]=target
checks={'files':{name:{'sha256':digest(path),'bytes':path.stat().st_size} for name,path in files.items()},'excluded':excluded,
        'voice_verification_outcome':a.voice_outcome,
        'research_outcome':a.research_outcome,
        'no_private_configs_device_credentials_model_keys_or_sqlite_databases':True,
        'data_attribution':'Open-Meteo / NOAA-NCEP / Copernicus CAMS-ECMWF; GeoNames; DB-IP; CC-BY-4.0. Model estimates, compiled/filtered by this project.'}
secrets=set()
def collect_private(value):
 if isinstance(value,dict):
  for key,item in value.items():
   if str(key).lower() in ('password','uuid','secret','token','api-key','server','credential','device_id') and isinstance(item,str) and len(item)>=8:
    secrets.add(item.encode())
   collect_private(item)
 elif isinstance(value,list):
  for item in value:collect_private(item)
collect_private(json.loads((r/'private/voice-test-device.json').read_text()))
collect_private(json.loads((r/'private/voice-test-device-account2.json').read_text()))
provided_key=Path('/home/jt/.config/xiaozhi-weather43/enterprise-model-key').read_bytes().strip()
assert provided_key
secrets.add(provided_key)
for config in Path('/home/jt/.config/xiaozhi-weather43').glob('config*.yaml'):
 collect_private(yaml.safe_load(config.read_text()))
assert secrets
matches=[]
overlap=max(map(len,secrets))-1
for name,path in files.items():
 with path.open('rb') as stream:
  tail=b''
  while True:
   block=stream.read(1048576)
   if not block:break
   combined=tail+block
   if any(value in combined for value in secrets):
    matches.append(name);break
   tail=combined[-overlap:] if overlap else b''
assert not matches, 'Known private credential found in allowlisted files: '+','.join(matches)
checks['server_exact_fixture_and_egress_secret_scan_passed']=True
(out/'checksums.json').write_text(json.dumps(checks,indent=2))
with tarfile.open(out/'raw-results.tar.gz','w:gz') as tar:
 for name,path in files.items():tar.add(path,arcname=name,recursive=False)
 tar.add(out/'checksums.json',arcname='checksums.json',recursive=False)
(out/'archive-receipt.json').write_text(json.dumps({'file':'raw-results.tar.gz','sha256':digest(out/'raw-results.tar.gz'),'bytes':(out/'raw-results.tar.gz').stat().st_size,'files':len(files)},indent=2))
print(json.dumps({'export':str(out),'files':len(files),'archive_bytes':(out/'raw-results.tar.gz').stat().st_size}))
