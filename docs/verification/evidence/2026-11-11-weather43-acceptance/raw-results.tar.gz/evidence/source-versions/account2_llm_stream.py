"""Bounded real model stream with a user-authorized key from stdin."""
import asyncio
import hashlib
import json
import sys
import time
import aiohttp


async def main():
    key=json.load(sys.stdin)['key']
    report={'scope':'direct new-account streaming preflight, not voice benchmark',
            'max_tokens':256,'production_configuration_changed':False,'keys_exported':False}
    start=time.monotonic();content=[];reasoning=0;size=0;done=False
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30),trust_env=False) as client:
            async with client.post('https://aimarket.hncig.cn/v1/chat/completions',
                    headers={'Authorization':'Bearer '+key},allow_redirects=False,
                    json={'model':'qwen3.8-flash','messages':[{'role':'user','content':'\u53ea\u56de\u7b54\u8fde\u63a5\u6210\u529f'}],
                          'stream':True,'max_tokens':256,'enable_thinking':False}) as response:
                report['http']=response.status
                if response.status==200:
                    async for raw in response.content:
                        size+=len(raw)
                        if size>65536:raise ValueError('response_size_limit')
                        if not raw.startswith(b'data:'):continue
                        value=raw[5:].strip()
                        if value==b'[DONE]':done=True;break
                        x=json.loads(value)
                        if 'error' in x:raise ValueError('model_stream_error')
                        choices=x.get('choices',[])
                        if not choices:continue
                        delta=choices[0].get('delta',{})
                        if isinstance(delta.get('content'),str):content.append(delta['content'])
                        if isinstance(delta.get('reasoning_content'),str):reasoning+=len(delta['reasoning_content'])
                        reason=choices[0].get('finish_reason')
                        if reason in ['stop','length','content_filter']:report['finish_reason']=reason
    except Exception as e:report['exception_class']=type(e).__name__
    text=''.join(content)
    report.update(done=done,content_chars=len(text),reasoning_chars=reasoning,
                  content_sha256=hashlib.sha256(text.encode()).hexdigest(),
                  succeeded=report.get('http')==200 and done and bool(text),elapsed_s=time.monotonic()-start)
    print('WEATHER43_ACCOUNT2_LLM '+json.dumps(report))


asyncio.run(main())
