"""Read a user-authorized key on stdin; emit only a sanitized diagnostic."""
import asyncio
import json
import re
import sys
import time

import aiohttp

BASE = 'https://aimarket.hncig.cn/v1/'
ASR = 'qwen-audio-3.0-asr-flash-filetrans'
LLM = 'qwen3.8-flash'


async def main():
    key = json.load(sys.stdin)['key']
    assert re.fullmatch(r'sk-[A-Za-z0-9_-]{12,128}', key)
    report = {'scope': 'direct user-authorized account preflight; not a voice benchmark',
              'model_base': BASE, 'keys_exported': False, 'production_configuration_changed': False,
              'input': 'Alibaba official public welcome.mp3', 'stages': []}
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=8), trust_env=False) as client:
        async def request(label, path, payload=None, asynchronous=False):
            started = time.monotonic()
            headers = {'Authorization': 'Bearer ' + key}
            if asynchronous:
                headers['X-DashScope-Async'] = 'enable'
            async with client.request('GET' if payload is None else 'POST', BASE + path,
                                      headers=headers, json=payload, allow_redirects=False) as response:
                body = bytearray()
                async for chunk in response.content.iter_chunked(8192):
                    body.extend(chunk)
                    assert len(body) <= 65536
                try:
                    data = json.loads(body)
                except ValueError:
                    data = {}
                if not isinstance(data, dict):
                    data = {}
                error = data.get('error') or {}
                message = data.get('message') or (error.get('message') if isinstance(error, dict) else '') or ''
                message = str(message).replace(key, '[REDACTED]')
                message = re.sub(r'https?://[^\s"<>]+', '[URL]', message)
                message = re.sub(r'(?i)(?:sk-|bearer\s+)[A-Za-z0-9._-]+', '[REDACTED]', message)
                code = data.get('code') or (error.get('code') if isinstance(error, dict) else None)
                report['stages'].append({'operation': label, 'http': response.status,
                                         'code': code if isinstance(code, str) and re.fullmatch(r'[A-Za-z0-9_.:-]{1,100}', code) else None,
                                         'sanitized_message': message[:500],
                                         'elapsed_s': time.monotonic() - started})
                return response.status, data

        async def checks():
            status, data = await request('models', 'models')
            models = data.get('data', [])
            ids = {x.get('id') for x in models if isinstance(x, dict)} if isinstance(models, list) else set()
            report.update(models_http=status, asr_model_listed=ASR in ids, llm_model_listed=LLM in ids)
            if status != 200:
                return
            status, data = await request('asr_submit', 'services/audio/asr/transcription',
                                        {'model': ASR, 'input': {'file_urls': [
                                            'https://dashscope.oss-cn-beijing.aliyuncs.com/audios/welcome.mp3']},
                                         'parameters': {}}, asynchronous=True)
            task = data.get('output', {}).get('task_id')
            report['asr_accepted_task'] = status == 200 and isinstance(task, str) and bool(re.fullmatch(r'[A-Za-z0-9_-]{1,128}', task))
            if not report['asr_accepted_task']:
                return
            for _ in range(20):
                status, data = await request('asr_poll', 'tasks/' + task)
                state = data.get('output', {}).get('task_status')
                report['asr_task_status'] = state if state in ('PENDING', 'RUNNING', 'SUCCEEDED', 'FAILED', 'CANCELED') else 'unknown'
                if status != 200 or state not in ('PENDING', 'RUNNING'):
                    break
                await asyncio.sleep(1)
            report['asr_succeeded'] = status == 200 and report['asr_task_status'] == 'SUCCEEDED'
            if report['asr_succeeded']:
                status, data = await request('llm_short', 'chat/completions', {
                    'model': LLM, 'messages': [{'role': 'user', 'content': '\u53ea\u56de\u7b54\u8fde\u63a5\u6210\u529f'}],
                    'stream': False, 'max_tokens': 16, 'enable_thinking': False})
                report['llm_succeeded'] = status == 200 and bool(data.get('choices', [{}])[0].get('message', {}).get('content'))
        try:
            await asyncio.wait_for(checks(), timeout=80)
        except Exception as error:
            report['exception_class'] = type(error).__name__
    print('WEATHER43_ACCOUNT2_PREFLIGHT ' + json.dumps(report))


asyncio.run(main())
