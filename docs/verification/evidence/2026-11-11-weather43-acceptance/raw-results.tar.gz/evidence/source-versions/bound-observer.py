"""Bound the already-running, exact weather43 observer without changing history."""
import argparse
from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path
import signal,time

p=argparse.ArgumentParser()
p.add_argument('--root',type=Path,required=True)
p.add_argument('--pid',type=int,required=True)
p.add_argument('--deadline',required=True)
a=p.parse_args();r=a.root.resolve();deadline=datetime.fromisoformat(a.deadline).timestamp()
done=r/'evidence/update-observation/completed.json'
while time.time()<deadline and not done.exists():time.sleep(min(30,max(0,deadline-time.time())))
report={'at':datetime.now(timezone.utc).isoformat(),'deadline':a.deadline,'completed':done.exists(),
        'observer_pid':a.pid,'signalled':False,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
proc=Path('/proc/%d'%a.pid)
if not done.exists() and proc.exists():
 argv=proc.joinpath('cmdline').read_bytes().decode().split('\0')
 assert Path(argv[0]).name=='python3'
 assert str(r/'scripts/weather43/observe_updates.py') in argv
 assert '--output' in argv and argv[argv.index('--output')+1]==str(r/'evidence/update-observation')
 os.kill(a.pid,signal.SIGTERM);report['signalled']=True
with (r/'evidence/update-observation/deadline-guard-result.json').open('x') as f:json.dump(report,f,indent=2)
